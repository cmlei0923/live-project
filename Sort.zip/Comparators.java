import java.util.Comparator;

public class Comparators {
    public static Comparator<Town> AVG = Comparator.comparingInt(o -> (int) o.getAvg());

}
