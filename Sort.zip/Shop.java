public class Shop {

    private String name;
    private String address;
    private double grade;
    private double cost;

    public Shop() {
    }

    public Shop(String name, String address, double grade, double cost) {
        this.name = name;
        this.address = address;
        this.grade = grade;
        this.cost = cost;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getGrade() {
        return grade;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
