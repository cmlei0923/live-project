import java.util.List;

public class Town {

    String name;
    List<Shop> shopList;
    double avg;

    public Town(String name) {
        this.name = name;
    }

    public Town(String name, List<Shop> shopList) {
        this.name = name;
        this.shopList = shopList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Shop> getShopList() {
        return shopList;
    }

    public void setShopList(List<Shop> shopList) {
        this.shopList = shopList;
    }

    public double getAvg() {
        return avg;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }
}
