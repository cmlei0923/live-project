import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Sort {

    List<Shop> shopList = new ArrayList<>();
    List<Town> townList = new ArrayList<>();
    List<String> shopName = new ArrayList<>();
    List<Double> avgList = new ArrayList<>();



    public void sort(){

        shopList = RestaurantRank.get();
        for(Shop shop:shopList)  {
            if(shopName.contains(shop.getName())){
                for(Town town:townList){
                    if(town.getName().equals(shop.getName())){
                        town.getShopList().add(shop);
                    }
                }
            }else{
                shopName.add(shop.getName());
                List<Shop> shops = new ArrayList<>();
                shops.add(shop);
                townList.add(new Town(shop.getName(),shops));

            }
        }
        for (Town town:townList){
            double avg=0.0;
            for(int i=0;i<town.getShopList().size();i++){
                double sum = 0.0;
                sum += town.getShopList().get(i).getGrade();
                avg = sum/town.getShopList().size();

            }
            System.out.println(avg);
            town.setAvg(avg);
        }
        townList.sort(Comparators.AVG);
        for(Town town:townList){
            System.out.println(town.getName());
        }
    }



}
